
# Twitter Sentiment Tracker
# Summer 2022 ACO 499

Tracks sentiment over time with certain keywords

## Authors

- [Mitchell Hoikka](https://www.github.com/mhoikka)